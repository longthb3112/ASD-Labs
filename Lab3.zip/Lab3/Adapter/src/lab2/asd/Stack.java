package lab2.asd;

public interface Stack {
    void push(String str);
    String pop();
    boolean isEmpty();
    void print();
}
