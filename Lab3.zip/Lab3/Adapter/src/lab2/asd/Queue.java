package lab2.asd;

public interface Queue {
    void enQueue(String str);
    String deQueue();
    boolean isEmpty();
    void print();
}
