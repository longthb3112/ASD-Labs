package lab2.asd;

public interface Target {
     void push(String str);
     String pop();
     boolean isEmpty();
}
