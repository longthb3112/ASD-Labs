package lab2.asd;

public interface Iterator {
    public boolean hasNext();
    public Object next();
}
