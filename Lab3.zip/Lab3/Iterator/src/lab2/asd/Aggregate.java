package lab2.asd;

    public interface Aggregate {
        public Iterator getIterator();
    }

