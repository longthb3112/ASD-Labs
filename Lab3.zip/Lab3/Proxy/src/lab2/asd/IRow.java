package lab2.asd;

public interface IRow {
}
