package lab5.asd;

public class Agent {
    private String streetAddress;
    private String city;
    private String state;
    private String zipcode;
}
