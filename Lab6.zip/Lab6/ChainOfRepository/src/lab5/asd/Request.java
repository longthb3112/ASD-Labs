package lab5.asd;

public class Request {
    private CallRecord callRecord;

    public CallRecord getCallRecord() {
        return callRecord;
    }

    public void setCallRecord(CallRecord callRecord) {
        this.callRecord = callRecord;
    }
}
