package lab5.asd;

public interface Command {
    void execute();
    void undo();
}
