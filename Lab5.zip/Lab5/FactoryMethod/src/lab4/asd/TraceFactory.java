package lab4.asd;

public interface TraceFactory {
    Trace createTrace(String type);
}
