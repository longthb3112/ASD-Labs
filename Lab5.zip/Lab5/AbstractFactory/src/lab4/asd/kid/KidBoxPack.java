package lab4.asd.kid;

import lab4.asd.Packaging;

public class KidBoxPack implements Packaging {
    @Override
    public float getCost() {
        return 0.25f;    }
}
