package lab4.asd;

public interface Packaging {
    float getCost();
}
