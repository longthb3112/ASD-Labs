package lab4.asd;

public interface IPackageLevelFactory {
    PackAbstract getPackageLevel(String type);
}
