package lab4.asd.business;

import lab4.asd.Packaging;

public class BusinessBoxPack implements Packaging {
    @Override
    public float getCost() {
        return 1f;    }
}
