package lab4.asd.business;

import lab4.asd.Packaging;

public class BusinessBagPack implements Packaging {
    @Override
    public float getCost() {
        return 0.5f;    }
}
