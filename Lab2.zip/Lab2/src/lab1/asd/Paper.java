package lab1.asd;

public class Paper {
    public void write(String message){
        Pencil.getPencil().write(message);
    }
}
